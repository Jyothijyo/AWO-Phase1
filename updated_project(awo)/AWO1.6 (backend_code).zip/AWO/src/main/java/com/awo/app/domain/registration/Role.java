package com.awo.app.domain.registration;

public enum Role {
	DONOR, USER, HOSPITAL, BLOODBANK, ADMIN
	

}
