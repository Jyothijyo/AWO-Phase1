package com.awo.app.constant;

public enum StatusCode {

	SUCCESS, ERROR;
}
