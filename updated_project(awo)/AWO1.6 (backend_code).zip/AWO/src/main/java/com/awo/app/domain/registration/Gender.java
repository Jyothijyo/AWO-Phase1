package com.awo.app.domain.registration;

public enum Gender {
	MALE, FEMALE

}
