package com.awo.app.requestRaise.domain;

public enum Status {

	OPEN, INPROCESS, CANCEL
}
