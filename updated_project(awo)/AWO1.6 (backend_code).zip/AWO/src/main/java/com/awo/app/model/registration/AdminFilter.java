package com.awo.app.model.registration;

import org.w3c.dom.Text;

public class AdminFilter {
	
	private String firstName;
	
	private String mobile;
	
	private String address;
	

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	

	
	
	

}
